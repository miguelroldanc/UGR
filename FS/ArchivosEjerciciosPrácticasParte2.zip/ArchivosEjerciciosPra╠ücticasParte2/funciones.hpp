#define N 10

void Rellenar ( int (&tn) [N] );
void Invertir ( int (&tn) [N] ); 
void Mostrar  ( const int (&tn) [N] );


