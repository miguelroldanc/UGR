/* Rellena una tabla de enteros y invierte su contenido  */

#include "funciones.hpp" 

int main()
{
   int tnum[N];

   Rellenar (tnum);
   Invertir (tnum);
   Mostrar  (tnum);
}

