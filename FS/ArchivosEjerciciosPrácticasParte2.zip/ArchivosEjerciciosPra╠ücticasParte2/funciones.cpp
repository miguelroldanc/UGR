#include "funciones.hpp"
#include <iostream>
using namespace std;

/********************************************************/

void Rellenar ( int (&tn) [N] )
{
   int i;

   for(i=0;i<N;i++)
   {
      cout << "Introduzca el valor " << i+1 << ":" << flush ;
      cin >> tn[i] ; 
   }
}

/********************************************************/

void Invertir ( int (&tn) [N] )
{
   int i, aux;

   for (i=0;i<N/2;i++)
   {
      aux= tn[i];
      tn[i]= tn[N-i-1];
      tn[N-i-1]= aux;
   }
}

/********************************************************/

void Mostrar ( const int (&tn) [N] )
{
   int i; 

   for (i=0;i<N;i++)
      cout << "valor " << i+1 << ": " << tn[i+1] << "\n" << flush; 
}

/********************************************************/
