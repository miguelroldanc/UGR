#include "InfoParada.h"

int InfoParada::GetIndice() const{
  return indice_parada;
}

bool InfoParada::EstaActiva() const{
  return activa;
}

ostream & operator<<(ostream & flujo, const InfoParada & parada){
  flujo << parada.indice_parada << " ";
  flujo << (parada.activa ? 'S' : 'N');
  return flujo;
}

istream & operator>>(istream & flujo, InfoParada &parada){
  char activa;
  flujo >> parada.indice_parada;
  flujo >> activa;
  parada.activa = (activa == 'S');
  return flujo;
}

