#include <cassert>
#include <fstream>
#include "RedMetro.h"

//Métodos privados auxiliares

void RedMetro::liberar(){
  //No es necesario comprobar si lineas==0
  //Si el puntero es NULL, delete no hace nada
  delete []lineas;
}

void RedMetro::reservar(int tam){
  //Comprobamos que el tamaño es no negativo
  assert(tam>=0);
  num_lineas = tam;
  //Comprobamos si num_lineas es >0
  //Hacer new con tamaño 0 es muy problemático
  if (num_lineas>0)
    lineas = new Linea[num_lineas];
  else
    lineas = 0;
}

void RedMetro::copiar(const RedMetro &otra){
  for(int i=0; i<num_lineas; i++)
    lineas[i] = otra.lineas[i];
//  memcpy(lineas, otra.lineas, num_lineas*sizeof(Linea));
}

//Fin métodos privados auxiliares

//Ej. 1.1.
RedMetro::RedMetro(){
  num_lineas = 0;
  lineas = 0;
}

RedMetro::~RedMetro(){
  liberar();
}

bool RedMetro::EstaVacia() const{
  return (num_lineas == 0);
}

//Ej. 1.1


//Ej. 1.2
RedMetro::RedMetro(const RedMetro & otra){
  reservar(otra.num_lineas);
  copiar(otra);
}

RedMetro & RedMetro::operator=(const RedMetro & otra){
  if (this != &otra){
    liberar();
    reservar(otra.num_lineas);
    copiar(otra);
  }
  return *this;
}
//Ej. 1.2



int RedMetro::GetNumLineas() const{
  return num_lineas;
}

int RedMetro::GetNumeroTotalParadas() const{
  int maximo = 1; //Inicializamos el máximo
  //Para cada línea
  for(int i=1; i<=GetNumLineas(); i++){
    //Para cada parada de la línea
    for(int j=1; j<=(*this)[i].GetNumParadas(); j++){
      //Obtengo el índice
      int indice = (*this)[i][j].GetIndice();
      //Actualizo el máximo
      maximo = (indice > maximo ? indice: maximo);
    }
  }
  return maximo;
}

Linea & RedMetro::operator[](int i){
  //El parámetro i se mueve entre 1 y num_lineas
  assert(i>0); assert(i<=num_lineas);
  //Restamos 1 para indexar el vector de lineas
  return lineas[i-1];
}

Linea & RedMetro::operator[](int i) const{
  //El parámetro i se mueve entre 1 y num_lineas
  assert(i>0); assert(i<=num_lineas);
  //Restamos 1 para indexar el vector de lineas
  return lineas[i-1];
}

RedMetro & RedMetro::operator+=(const Linea & linea){
  //Reservamos espacio para num_lineas +1 líneas
  Linea* nueva = new Linea[num_lineas+1];
  //Copiamos las líneas actuales
  for(int i=0; i<num_lineas; i++)
    nueva[i] = lineas[i];
  //Liberamos el antiguo vector y actualizamos el puntero
  delete[] lineas;
  lineas = nueva;
  //Copiamos la nueva línea
  lineas[num_lineas] = linea;
  //Actualizamos el número de líneas
  num_lineas++;
  //Devolvemos el objeto por referencia para poder encadenar
  return *this;
  
}

//Ej. 2.2
ostream & operator<<(ostream & flujo, const RedMetro & red){
  //Escribimos el número de líneas
  flujo << red.num_lineas << endl;
  //Escribimos cada una de las líneas
  for(int i=1; i<=red.num_lineas; i++){
    flujo << red[i];
  }
  //Devolvemos el flujo por referencia para encadenar
  return flujo;
}
//Ej. 2.2

//Ej. 2.3
istream & operator>>(istream & flujo, RedMetro & red){
  int cuantas_lineas;
  //Si la red tiene información, liberamos recursos
  if (red.num_lineas)
    red.liberar();
  //Leemos el número de líneas
  flujo >> cuantas_lineas;
  //Reservamos
  red.reservar(cuantas_lineas);
  //Leemos cada una de las líneas
  for(int i=1; i<=red.num_lineas; i++)
    flujo >> red[i];
  //Devolvemos el flujo por referencia para encadenar
  return flujo;
}
//Ej. 2.3

//Ej. 3
RedMetro::RedMetro(const string filename){
  //Abrimos el fichero
  ifstream f(filename, ios::in);
  //Comprobamos la apertura
  if (!f){
    cerr << "Error abriendo el fichero " << filename << endl;
    exit(1);
  }
  else{ //Si se ha abierto bien el fichero
    string magica;
    //Leemos la primera línea
    getline(f, magica);
    //Comprobamos la cadena mágica
    if (magica != "METRO"){
      cerr << "Error: el fichero no contiene la cadena mágica" << endl;
      exit(1);
    }
    else{
      //Ponemos num_lineas a 0 porque el objeto se acaba de crear
      //Así la información del objeto es consistente y
      //podemos usar el operador >> sin problema
      this->num_lineas = 0;
      //Delegamos en el operador >> para leer la red
      f >> *this;
    }
  }
}
//Ej 3


//Ej. 4
double RedMetro::calidad() const{
  //Contamos las paradas activas
  int paradas_activas = 0;
  for(int i=1; i<=this->num_lineas; i++)
    paradas_activas += (*this)[i].paradas_activas();
  //Alternativa que no delega en un método de la clase Linea
  //La variante anterior está mejor estructurada
//  paradas_activas = 0;
//  for(int i=1; i<=this->num_lineas; i++)
//    for(int j=1; j<=(*this)[i].GetNumParadas(); j++)
//      paradas_activas += (*this)[i][j].EstaActiva() ? 1 : 0;
  //Devolvemos el factor de calidad
  return (this->num_lineas* 0.3 + paradas_activas*0.7);
}

bool RedMetro::operator==(const RedMetro &otra) const{
  return (this->calidad() == otra.calidad());
}

bool RedMetro::operator!=(const RedMetro &otra) const{
  //Delegamos en el operador ==
  return !(*this == otra);
}

bool RedMetro::operator>(const RedMetro &otra) const{
  return (this->calidad()>otra.calidad());
}

//Ej. 4

bool RedMetro::operator>=(const RedMetro &otra) const{
  //Delegamos en los operadores == y >
  return ((*this>otra) || (*this == otra));
}

bool RedMetro::operator<=(const RedMetro &otra) const{
  //Delegamos en el operador >
  return !(*this > otra);
}

bool RedMetro::operator<(const RedMetro &otra) const{
  //Delegamos en el operador >=
  return !(*this >= otra);
}


//Ej. 5.1
int RedMetro::MejorConectada() const{
  int num_total = GetNumeroTotalParadas();
  int  confluencias[num_total];
  for(int i=0; i<num_total; i++)
    confluencias[i] = 0;

  //Contabilizamos las confluencias de las paradas
  //Dicho de otra manera, contamos cuantas veces aparece
  //cada parada en una línea cualquiera
  for(int i=1; i<=num_lineas; i++){
    for(int j=1; j<=(*this)[i].GetNumParadas(); j++){
      confluencias[(*this)[i][j].GetIndice()-1]++;
    }
      
    //Si queremos evitar contabilizar dos veces una parada
    //en las líneas circulares (comienzan y acaban en la misma
    //parada), podemos hacer aquí la comprobación y descontar
    //Comparamos el índice de la primera y última paradas
    if((*this)[i][1].GetIndice() ==
       (*this)[i][(*this)[i].GetNumParadas()].GetIndice())
      confluencias[(*this)[i][1].GetIndice()-1]--;
  }

  //Localizamos el máximo del vector de confluencias
  //Devolvemos el índice real, no la posición en el vector
  //Por eso incrementamos en 1
  return maximo(confluencias, num_total)+1;
}
//Ej. 5.1

//Función auxiliar. Cálculo del máximo
//Devuelve la posición del máximo del vector
int maximo(const int * vector, int tam){
  int pos_maximo = 0;
  for (int i=1; i<tam; i++)
    if (vector[i] > vector[pos_maximo])
      pos_maximo = i;
  return pos_maximo;
}



