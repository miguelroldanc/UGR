#include <iostream>

//Ej. 6
#include <iostream>
#include "RedMetro.h"

int main(int argc, const char * argv[]) {
  
  if(argc!=3){
    cerr << "Error: número de argumentos incorrecto" << endl;
    cerr << "Uso: " << argv[0] << "fich_red1 fich_red2" << endl;
    exit(1);
  }
  else{
    RedMetro red1(argv[1]), red2(argv[2]), *mejor_red;
    //Para no repetir código, usamos un puntero a RedMetro
    if (red1 > red2){
      cout << "La red " << argv[1] << " es la mejor red" << endl;
      mejor_red = &red1;
    }
    else{
      cout << "La red " << argv[2] << " es la mejor red" << endl;
      mejor_red = &red2;
    }
    //cout << mejor_red;
    
    cout << "Informe de operatividad de líneas:" << endl;
    for(int i=1; i<=mejor_red->GetNumLineas(); i++){
      cout << "La línea " << i
      << ((*mejor_red)[i].EstaTotalmenteOperativa() ? " sí" : " no")
      << " está totalmente operativa" << endl;
    }
    
    cout << "Parada mejor conectada: "
         << mejor_red->MejorConectada() << endl;
    return 0;
  }
}
//Ej. 6
