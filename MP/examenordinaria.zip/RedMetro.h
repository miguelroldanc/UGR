#ifndef RedMetro_hpp
#define RedMetro_hpp

#include <iostream>
#include "Linea.h"

using namespace std;

class RedMetro{
private:
  int num_lineas;
  Linea* lineas;
public:
  RedMetro();
  ~RedMetro();
  RedMetro(const RedMetro & otra);
  RedMetro(const string filename);
  RedMetro & operator=(const RedMetro & otra);
  int GetNumLineas() const;
  int GetNumeroTotalParadas() const;
  Linea & operator[](int i);
  Linea & operator[](int i) const;
  bool EstaVacia() const;
  RedMetro & operator+=(const Linea & linea);
  friend ostream & operator<<(ostream & flujo, const RedMetro & red);
  friend istream & operator>>(istream & flujo, RedMetro & red);
  bool operator==(const RedMetro & otra) const;
  bool operator!=(const RedMetro & otra) const;
  bool operator>(const RedMetro & otra) const;
  bool operator>=(const RedMetro & otra) const;
  bool operator<(const RedMetro & otra) const;
  bool operator<=(const RedMetro & otra) const;
  int MejorConectada() const;
private:
  void liberar();
  void reservar(int tam);
  void copiar(const RedMetro & otra);
  double calidad() const;
};

int maximo(const int * vector, int tam);

#endif /* RedMetro_hpp */
