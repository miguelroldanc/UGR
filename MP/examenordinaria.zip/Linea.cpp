#include <cassert>
#include <iostream>
#include "Linea.h"

using namespace std;

Linea::Linea(){
  num_paradas = 0;
  paradas = 0;
}

Linea::~Linea(){
  liberar();
}

Linea::Linea(const Linea & otra){
  copiar(otra);
}

Linea & Linea::operator=(const Linea & otra){
  if(this != & otra){
    liberar();
    copiar(otra);
  }
  return *this;
}


int Linea::GetNumParadas() const{
  return num_paradas;
}

InfoParada & Linea::operator[](int i){
  //El parámetro i se mueve entre 1 y num_paradas
  assert(i>0);assert(i<=num_paradas);
  //Restamos 1 para indexar el vector de paradas
  return this->paradas[i-1];
}

InfoParada & Linea::operator[](int i) const{
  //El parámetro i se mueve entre 1 y num_paradas
  assert(i>0); assert(i<=num_paradas);
  //Restamos 1 para indexar el vector de paradas
  return this->paradas[i-1];
}

//Ej. 2.1
Linea & Linea::operator+=(const InfoParada & infoparada){
  //Reservamos espacio para albergar 1 parada más
  InfoParada* nueva = new InfoParada[num_paradas+1];
  //Copiamos las paradas al nuevo vector
  for(int i=0; i<num_paradas; i++)
    nueva[i] = paradas[i];
  //Liberamos el antiguo vector
  delete[] paradas;
  //Actualizamos el puntero
  paradas = nueva;
  //Insertamos la nueva parada
  paradas[num_paradas] = infoparada;
  //Incrementamos el número de paradas de la línea
  num_paradas++;
  //Devolvemos la referencia a la línea
  //para poder encadenar el operador
  return *this;
}
//Ej. 2.1


ostream & operator<<(ostream & flujo, const Linea & linea){
  //Escribimos el número de paradas
  flujo << linea.num_paradas << endl;
  //Escribimos cada una de las paradas
  //Delegamos en el operador << de la clase InfoParada
  //El índice se mueve de 1 a num_paradas porque
  //el operador [] trabaja de 1 a n, no de 0 a n-1
  for(int i=1; i<=linea.num_paradas; i++)
    flujo << linea[i] << endl;
  return flujo;
}

istream & operator>>(istream & flujo, Linea & linea){
  //Si la línea tiene paradas, liberamos memoria
  if(linea.num_paradas)
    linea.liberar();
  //Leemos el número de paradas
  flujo >> linea.num_paradas;
  //Reservamos el vector de paradas
  linea.paradas = new InfoParada[linea.num_paradas];
  //Leemos las paradas. El índice se mueve de 1 a num_paradas
  //porque el operador [] trabaja de 1 a n, no de 0 a n-1
  for(int i=1; i<=linea.num_paradas; i++){
    flujo >>linea[i];
  }
  return flujo;
}

int Linea::paradas_activas(){
  int cuantas = 0;
  for(int i=0; i<num_paradas; i++)
    if(paradas[i].EstaActiva()) cuantas++;
  return cuantas;
}


//Ej. 5.2
bool Linea::EstaTotalmenteOperativa() const{
  bool operativa = true;
  for(int i=0; i<GetNumParadas() && operativa; i++)
    operativa = operativa && this->paradas[i].EstaActiva();
//  Alternativa con if y el operador []
//  for(int i=1; i<=GetNumParadas() && operativa; i++)
//    if(!(*this)[i].EstaActiva())
//      operativa = false;
  return operativa;
}
//Ej. 5.2




//Métodos privados auxiliares

void Linea::liberar(){
  delete [] paradas;
}

void Linea::copiar(const Linea & otra){
  num_paradas = otra.num_paradas;
  paradas = new InfoParada[num_paradas];
  for(int i=0; i<num_paradas; i++)
    paradas[i] = otra.paradas[i];
}

