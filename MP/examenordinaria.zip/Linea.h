#ifndef Linea_hpp
#define Linea_hpp

#include "InfoParada.h"

class Linea{
private:
  int num_paradas;
  InfoParada * paradas;
public:
  Linea();
  ~Linea();
  Linea(const Linea & otra);
  Linea & operator=(const Linea & otra);
  int GetNumParadas() const;
  InfoParada & operator[](int i);
  InfoParada & operator[](int i) const;
  Linea & operator+=(const InfoParada & parada);
  friend ostream & operator<<(ostream & flujo, const Linea & linea);
  friend istream & operator>>(istream & flujo, Linea & linea);
  int paradas_activas();
  bool EstaTotalmenteOperativa() const;
private:
  void liberar();
  void copiar(const Linea & otra);
};

#endif /* Linea_hpp */
