#ifndef InfoParada_hpp
#define InfoParada_hpp

#include <iostream>

using namespace std;


class InfoParada{
private:
  int indice_parada;
  bool activa;
public:
  //No es necesario implementar constructor, destructor,
  //constructor de copia ni operador =
  //ya que los datos miembro son estáticos
  int GetIndice() const;
  bool EstaActiva() const;
  friend ostream & operator<<(ostream & flujo, const InfoParada & parada);
  friend istream & operator>>(istream & flujo, InfoParada & parada);
};

#endif /* InfoParada_hpp */
